<div class="partner-area ptb-100">
    <div class="container">
        <div class="partner-title">
            Trusted by world famous companies:
        </div>
        <div class="partner-slides owl-carousel owl-theme">
            <div class="partner-item">
                <a href="#" class="d-block">
                    <img src="assets/img/partner/partner3.png" alt="image">
                </a>
            </div>
            <div class="partner-item">
                <a href="#" class="d-block">
                    <img src="assets/img/partner/partner4.png" alt="image">
                </a>
            </div>
            <div class="partner-item">
                <a href="#" class="d-block">
                    <img src="assets/img/partner/partner1.png" alt="image">
                </a>
            </div>
            <div class="partner-item">
                <a href="#" class="d-block">
                    <img src="assets/img/partner/partner2.png" alt="image">
                </a>
            </div>
            <div class="partner-item">
                <a href="#" class="d-block">
                    <img src="assets/img/partner/partner5.png" alt="image">
                </a>
            </div>
            <div class="partner-item">
                <a href="#" class="d-block">
                    <img src="assets/img/partner/partner6.png" alt="image">
                </a>
            </div>
            <div class="partner-item">
                <a href="#" class="d-block">
                    <img src="assets/img/partner/partner7.png" alt="image">
                </a>
            </div>
            <div class="partner-item">
                <a href="#" class="d-block">
                    <img src="assets/img/partner/partner8.png" alt="image">
                </a>
            </div>
        </div>
    </div>
</div>