<!doctype html>
<html lang="zxx">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Link of CSS files -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/aos.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/all.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/odometer.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/remixicon.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/magnific-popup.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/meanmenu.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/swiper-bundle.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/owl.carousel.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/owl.theme.default.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">

        <title>FreshPay - Accueil</title>

        <link rel="icon" type="image/png" href="<?php echo e(asset('assets/img/favicon.png')); ?>">
    </head>
    <body>

        <!-- Start Navbar Area -->
        <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- End Navbar Area -->

        <!-- Start Banner Wrapper Area -->
        <div class="banner-wrapper-area">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-5 col-md-12">
                        <div class="banner-wrapper-content">
                            <span class="sub-title">PLATEFORME DE SOLUTIONS FINANCIERES</span>
                            <h1>Meilleure solution de paiement en ligne.</h1>
                            <p>Premier agrégateur de paiement en activité en République Démocratique du Congo. Nous sommes là depuis 2016.</p>
                            <a href="#" class="default-btn">Devenir marchand</a>
                        </div>
                    </div>
                    <div class="col-lg-7 col-md-12">
                        <div class="banner-wrapper-image">
                            <img src="<?php echo e(asset('assets/img/banner/banner-img1.png')); ?>" alt="banner-img">
                            <img src="<?php echo e(asset('assets/img/banner/banner-img2.png')); ?>" data-aos="fade-left" alt="banner-img">
                        </div>
                    </div>
                </div>
            </div>
            <div class="shape13"><img src="<?php echo e(asset('assets/img/shape/shape15.png')); ?>" alt="shape"></div>
            <div class="shape14"><img src="<?php echo e(asset('assets/img/shape/shape17.png')); ?>" alt="shape"></div>
            <div class="shape15"><img src="<?php echo e(asset('assets/img/shape/shape18.png')); ?>" alt="shape"></div>
        </div>
        <!-- End Banner Wrapper Area -->

        

        <!-- Start Overview Area -->
        <div class="overview-area ptb-100">
            <div class="container-fluid">
                <div class="row m-0">
                    <div class="col-xl-6 col-lg-12 col-md-12 p-0">
                        <div class="overview-content">
                            <h2>Qui sommes-nous?</h2>
                            <p><strong>FreshPay</strong>, fait partie d'un très grand réseau des africains passionnés par l'innovation technologique en offrant au monde les outils technologiques appropriés pour mener à bien leurs différents projets tout en contribuant à l'économie globale. </p>
                            <p><strong>FreshPay</strong> permet aux organisations marchandes et aux e-commerçants d'effectuer des transactions via différents operateurs Mobiles et avec des services de Cartes bancaires de manière simple et sécurisée.</p>
                            <ul class="features-list">
                                <li>
                                    <div class="icon">
                                        <i class=" ri-bank-card-2-fill"></i>
                                    </div>
                                    <h3>FreshPay</h3>
                                    <p>FreshPay offre un système de paiment en ligne dans le monde entier. La plateforme sert d'alternative au paiment par chèque ou par carte bancaire.</p>
                                </li>
                                <li>
                                    <div class="icon">
                                        <i class="ri-award-line"></i>
                                    </div>
                                    <h3>AirTime</h3>
                                    <p>Simplifiez-vous la vie et effectuez vos achats de crédits sur l'application FreshPay(AirTime) peut importe votre réseau téléphonique.</p>
                                </li>
                                <li>
                                    <div class="icon">
                                        <i class="ri-apps-fill"></i>
                                    </div>
                                    <h3>FreshPayOne</h3>
                                    <p>Notre application vous permettra d'acheter et de payer vos factures plus simplement et plus rapidement.</p>
                                </li>
                            </ul>
                            <div class="btn-box">
                                <a href="<?php echo e(route('about')); ?>" class="default-btn">En savoir plus</a>
                                <a href="features-1.html" class="link-btn">Nos Solutions</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-12 col-md-12 p-0">
                        <div class="overview-image bg1">
                            <img style="border-left: 1px solid orange; border-top: 1px solid orange;" src="<?php echo e(asset('assets/img/about.png')); ?>" alt="overview">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Overview Area -->

        <!-- Start Features Area -->
        
        <!-- End Features Area -->

        <!-- Start Software Integrations Area -->
        <div class="screenshots-area ptb-100 bg-black-color">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6 col-md-12 mb-2">
                        <div class="software-integrations-content">
                            <span class="sub-title">SOLUTION DE PAIEMENT MOBILE</span>
                            <h2 class="text-white">La révolution du paiement mobile.</h2>
                            <p class="text-white">Avec FreshPay, recevez des paiements partout en RDC sur votre site de E-commerce avec M-pesa, Airtel money, Orange money et Afrimoney</p>
                            <p class="text-white">FreshPay fournit des solutions innovantes et nécessaires au marché pour résoudre les problèmes locaux et fournir des solutions à vie aux PME et aux utilisateurs finaux en proposant des solutions de paiement proactives.</p>
                            
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12">
                        <div class="video-box">
                            <video class="w-100 popup-video" autoplay loop muted controls>
                                <source src="<?php echo e(asset('assets/img/video/freshpay.mp4')); ?>" type="video/mp4" />
                            </video>
                            <div class="shape">
                                <img class="shape1" src="<?php echo e(asset('assets/img/shape/shape1.png')); ?>" alt="shape1">
                                <img class="shape2" src="<?php echo e(asset('assets/img/shape/shape2.png')); ?>" alt="shape2">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="shape6"><img src="<?php echo e(asset('assets/img/shape/shape5.png')); ?>" alt="shape"></div>
        </div>
        <!-- End Software Integrations Area -->

        <!-- Start Features Area -->
        <div class="features-area pt-100 pb-75">
            <div class="container">
                <div class="section-title">
                    <span class="sub-title">NOS SOLUTIONS</span>
                    <h2>Solution de paiement tout-en-un!</h2>
                </div>
                <div class="row justify-content-center">
                    <div class="col-lg-4 col-sm-6 col-md-6">
                        <div class="features-item">
                            <div class="icon">
                                <i class=" ri-exchange-funds-line"></i>
                            </div>
                            <h3>Transfert d'Argent</h3>
                            <p>Un transfert d'argent devrait être aussi simple que l'envoi d'un message. Avec FreshPay, vous pouvez envoyer et recevoir de l'argent via notre application.</p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-sm-6 col-md-6">
                        <div class="features-item">
                            <div class="icon bg2">
                                <i class="ri-money-dollar-box-fill"></i>
                            </div>
                            <h3>Paiement Factures</h3>
                            <p>Avec FreshPay, effectuer vos règlements en utilisant notre service de Paiement Factures sur l'Appli FreshPay, sans effectuer le moindre déplacement</p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-sm-6 col-md-6">
                        <div class="features-item">
                            <div class="icon bg3">
                                <i class=" ri-phone-fill"></i>
                            </div>
                            <h3>Achat Crédit</h3>
                            <p>Simplifiez-vous la vie et effectuez vos achats de crédit sur l'application FreshPay avec n'importe quel réseaux de téléphonie et des données mobiles en RDC.</p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-sm-6 col-md-6">
                        <div class="features-item">
                            <div class="icon bg4">
                                <i class=" ri-money-dollar-box-fill"></i>
                            </div>
                            <h3>Paiement Marchand</h3>
                            <p>Si vous recherchez une solution robuste et sécurisée permettant à vos clients ou usagers de payer par mobile money ou carte bancaire, FreshPay est le partenaire idéal pour vous</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Features Area -->

        <!-- Start Screenshots Area -->
        <div class="screenshots-area bg-black-color ptb-100">
            <div class="container">
                <div class="section-title color-white">
                    <span class="sub-title">CAPTURES D'ECRAN</span>
                    <h2>Toutes les captures d'écran de l'application</h2>
                </div>
                <div class="screenshots-slides owl-carousel owl-theme">
                    <div class="single-screenshot-item">
                        <img src="<?php echo e(asset('assets/img/screenshots/screenshots1.png')); ?>" alt="screenshots">
                    </div>
                    <div class="single-screenshot-item">
                        <img src="<?php echo e(asset('assets/img/screenshots/screenshots2.png')); ?>" alt="screenshots">
                    </div>
                    <div class="single-screenshot-item">
                        <img src="<?php echo e(asset('assets/img/screenshots/screenshots3.png')); ?>" alt="screenshots">
                    </div>
                    <div class="single-screenshot-item">
                        <img src="<?php echo e(asset('assets/img/screenshots/screenshots4.png')); ?>" alt="screenshots">
                    </div>
                    <div class="single-screenshot-item">
                        <img src="<?php echo e(asset('assets/img/screenshots/screenshots5.png')); ?>" alt="screenshots">
                    </div>
                    <div class="single-screenshot-item">
                        <img src="<?php echo e(asset('assets/img/screenshots/screenshots4.png')); ?>" alt="screenshots">
                    </div>
                </div>
            </div>
        </div>
        <!-- End Screenshots Area -->

        

        <!-- Start App Download Area -->
        <div class="app-download-area pb-100">
            <div class="container">
                <div class="app-download-inner bg-gray">
                    <div class="row align-items-center">
                        <div class="col-lg-6 col-md-12">
                            <div class="app-download-content">
                                <span class="sub-title">DOWNLOAD APP</span>
                                <h2>Téléchargez gratuitement FreshPayOne sur Apple et Play Store.</h2>
                                <p>Téléchargez notre application et commencez avec vos transactions dès maintenant.</p>
                                <div class="btn-box">
                                    <a href="#" class="playstore-btn" target="_blank">
                                        <img src="<?php echo e(asset('assets/img/play-store.png')); ?>" alt="image">
                                        Get It On
                                        <span>Google Play</span>
                                    </a>
                                    <a href="#" class="applestore-btn" target="_blank">
                                        <img src="<?php echo e(asset('assets/img/apple-store.png')); ?>" alt="image">
                                        Download on the
                                        <span>Apple Store</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-12">
                            <div class="app-download-image" data-aos="fade-up">
                                <img src="<?php echo e(asset('assets/img/app/app-img4.png')); ?>" alt="app-img">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End App Download Area -->


        <!-- Start Partner Area -->
        <div class="partner-area pb-100">
            <div class="container">
                <div class="partner-title">
                    Ils nous font confiance :
                </div>
                <div class="partner-slides owl-carousel owl-theme">
                    <div class="partner-item">
                        <a href="#" class="d-block">
                            <img src="<?php echo e(asset('assets/img/partner/partner3.png')); ?>" alt="image">
                        </a>
                    </div>
                    <div class="partner-item">
                        <a href="#" class="d-block">
                            <img src="<?php echo e(asset('assets/img/partner/partner4.png')); ?>" alt="image">
                        </a>
                    </div>
                    <div class="partner-item">
                        <a href="#" class="d-block">
                            <img src="<?php echo e(asset('assets/img/partner/partner1.png')); ?>" alt="image">
                        </a>
                    </div>
                    <div class="partner-item">
                        <a href="#" class="d-block">
                            <img src="<?php echo e(asset('assets/img/partner/partner2.png')); ?>" alt="image">
                        </a>
                    </div>
                    <div class="partner-item">
                        <a href="#" class="d-block">
                            <img src="<?php echo e(asset('assets/img/partner/partner5.png')); ?>" alt="image">
                        </a>
                    </div>
                    <div class="partner-item">
                        <a href="#" class="d-block">
                            <img src="<?php echo e(asset('assets/img/partner/partner6.png')); ?>" alt="image">
                        </a>
                    </div>
                    <div class="partner-item">
                        <a href="#" class="d-block">
                            <img src="<?php echo e(asset('assets/img/partner/partner7.png')); ?>" alt="image">
                        </a>
                    </div>
                    <div class="partner-item">
                        <a href="#" class="d-block">
                            <img src="<?php echo e(asset('assets/img/partner/partner8.png')); ?>" alt="image">
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Partner Area -->

        <!-- Start Footer Area -->
        <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- End Footer Area -->

        <div class="go-top"><i class="ri-arrow-up-s-line"></i></div>

        <!-- Link of JS files -->
        <script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/owl.carousel.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/swiper-bundle.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/magnific-popup.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/meanmenu.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/appear.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/odometer.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/form-validator.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/contact-form-script.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/ajaxchimp.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/aos.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
    </body>
</html><?php /**PATH C:\laragon\www\freshpwebsite\resources\views/welcome.blade.php ENDPATH**/ ?>